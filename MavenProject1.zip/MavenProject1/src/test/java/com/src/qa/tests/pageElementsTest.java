package com.src.qa.tests;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.*;

import com.src.qa.base.BaseClass;
import com.src.qa.pages.pageElements;

public class pageElementsTest extends BaseClass{

	pageElements PGelement;
	
	public pageElementsTest() throws IOException {
		super();
	          	
	}
	
	@BeforeMethod
	public void setup() { 
    
		initialization();	
		try {
			PGelement = new pageElements();
			PGelement.NavigateElements();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

	@Test
	public void TestPageElementTitle() {
		
		
//		String Title  = PGelement.GetTitleText();
//		
//		Assert.assertEquals(Title,"ToolsQA");
		
		String URL = driver.getCurrentUrl();
		Assert.assertEquals(URL ,"https://demoqa.com/elements");
		
		
	}
	
	
	
	
	@AfterMethod
	public void TearDown() {
		driver.quit();
	}


}
