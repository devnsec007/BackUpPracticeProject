package javaSeleniumPractice;

public class testMultipleMainClasses {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Main 1");
	}

}

class B{
	
	public static void main(String[] args) {
		
		System.out.println("Main 2");
	}
	
}


class C{
	
	public static void main(String[] args) {
		
		System.out.println("Main 3");
	}
	
}
