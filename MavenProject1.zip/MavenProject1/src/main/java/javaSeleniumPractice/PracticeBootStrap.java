package javaSeleniumPractice;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;



public class PracticeBootStrap {

	public static void main(String[] args) {

	System.setProperty("webdriver.chrome.driver","C:\\Users\\DB\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get("https://www.seleniumeasy.com/test/");
		driver.findElement(By.xpath("//a[contains(text(),'List Box')]/parent::li[@class='dropdown']")).click();
		driver.findElement(By.xpath("//div[@class='at4win-header']/a")).click();
		
		String XpathfortheList = "//a[text()='Bootstrap List Box']/parent::li/parent::ul[@class='dropdown-menu']/li";
		
		List<WebElement> ListObj = driver.findElements(By.xpath(XpathfortheList));
		
		System.out.println("The number of Objects reiding in that list :: " + ListObj.size());
		
		int i=0;
		
		for(WebElement Element:ListObj) {
			i++;
			System.out.println("ListItem :: " + i + ":: " + Element.getText());
			
			
		}
		
		for(WebElement Element:ListObj) {
			
			if(Element.getText().equalsIgnoreCase("Bootstrap List Box"))
			{
				Element.click();
				break;
			}
			
		}
		

		driver.findElement(By.xpath("//div[@class='well text-right']/descendant::li[@class='list-group-item'  and text()='Morbi leo risus']")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-default btn-sm move-right']")).click();
		
		
		
		
		
	}

}
