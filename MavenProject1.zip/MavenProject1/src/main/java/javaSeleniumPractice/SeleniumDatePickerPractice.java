package javaSeleniumPractice;

import java.awt.RenderingHints.Key;
import java.util.List;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;




public class SeleniumDatePickerPractice {

	WebDriver driver;
	String MonthAndYearToPick=null;
	String DateToBPicked = null;
	
	@BeforeClass
	public void Setup() {
		
		
		//Driver Initialization and Default site reach
		System.setProperty("webdriver.chrome.driver","F:\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
		driver= new ChromeDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		
		driver.get("https://www.seleniumeasy.com/test/");
		
		//Handling the Add thats appearing
		if(driver.findElement(By.xpath("//div[@class='at4win-header']/a")).isEnabled())
			driver.findElement(By.xpath("//div[@class='at4win-header']/a")).click();
		
		//Navigation to the Desired Section	
		
		NavigationToDatePickers(driver);
		
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void NavigationToDatePickers(WebDriver driver) {
		
		driver.findElement(By.xpath("//li[@class='dropdown']/a[contains(text(),'Date pickers')]")).click();
		driver.findElement(By.xpath("//a[text()='Bootstrap Date Picker']")).click();
		
	}
	
	
	
	@Test
	public void TestDatePicker_Date_Range_Example() {
		
		driver.findElement(By.xpath("//div[@class='input-daterange input-group']/input[@class='form-control'][1]")).click();
		
		String NextButton = "//div[@class='datepicker datepicker-dropdown dropdown-menu datepicker-orient-left datepicker-orient-top']/descendant::th[@class='datepicker-switch' and @colspan='5'][1]/following-sibling::th";
			
		
		
		
		MonthAndYearToPick = "August 2021";
		DateToBPicked="25";
		
		
		while(true)
		{	
			
			if(MonthAndYearToPick.equals(driver.findElement(By.xpath("//div[@class='datepicker datepicker-dropdown dropdown-menu datepicker-orient-left datepicker-orient-top']/descendant::th[@class='datepicker-switch' and @colspan='5'][1]")).getText())) {
			break;
			}
			else {
			driver.findElement(By.xpath(NextButton)).click();
			}
			
		}
		
		
		List<WebElement> ROWELEMENT = driver.findElements(By.xpath("//div[@class='datepicker datepicker-dropdown dropdown-menu datepicker-orient-left datepicker-orient-top']/div[@class='datepicker-days']/table/tbody/tr"));
		
		
		
		for(WebElement Element:ROWELEMENT) {
			
			List<WebElement> COLOUMELEMENT =Element.findElements(By.tagName("td"));
			
			for(WebElement CELL_ELEMENT:COLOUMELEMENT)
			
				{
		
				if(CELL_ELEMENT.getAttribute("class").equalsIgnoreCase("Day")){
					
					
					if(CELL_ELEMENT.getText().equalsIgnoreCase(DateToBPicked)) {
						
						CELL_ELEMENT.click();
						
						break;
					}
					
					
				}
				
		
				
				}
			
			
			
		}
		
		
		// driver.findElement(By.tagName('body').send_keys(Keys.TAB);
		
		
//Actions AC = new Actions(driver);
//AC.sendKeys(Keys.ESCAPE).build().perform();
	

//AC.moveByOffset(200, 200).click().build().perform();

//		WebElement WB= driver.findElement(By.xpath("//div[text()='Date Example :']"));
//		AC.moveToElement(WB).click().build().perform();
	}
	
	
}
