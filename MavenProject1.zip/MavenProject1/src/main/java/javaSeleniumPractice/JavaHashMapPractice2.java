package javaSeleniumPractice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class JavaHashMapPractice2 {

	public static void main(String[] args) {
		
		HashMap<Integer,String> DBMAP=new HashMap<Integer,String>();          
		DBMAP.put(100,"Amit");    
		DBMAP.put(101,"Vijay");    
		DBMAP.put(102,"Rahul"); 
	      
	      
		// DBMAP.entrySet().stream().sorted(Map.Entry.comparingByKey());
		
		//This works only in Java 1.8 and above
		
		TreeMap<Integer,String> DBTREE=new  TreeMap<Integer,String> (DBMAP);
		
		Iterator IT = DBTREE.keySet().iterator();
		
		while(IT.hasNext()) {
			
		int Key = (Integer) IT.next();
		
		System.out.println("Key:: " + Key+"  Value:: " + DBMAP.get(Key));
			
			
		}
	      
	}

}
