package javaSeleniumPractice;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.testng.annotations.Test;

public class PhantomJSDemo {

@Test

public void TEST001() {

	
	System.setProperty("phantomjs.binary.path", "C:\\Users\\Dev\\Downloads\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
	PhantomJSDriver driver = new PhantomJSDriver();
	
	driver.get("https://www.google.com");
	
	

}
	
	
	
}
