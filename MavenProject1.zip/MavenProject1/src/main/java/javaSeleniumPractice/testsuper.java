package javaSeleniumPractice;

public class testsuper {

	
	public static void ImSuper() {
		
		System.out.println("I am Super");
	}
	
	
}
