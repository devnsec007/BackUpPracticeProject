package javaSeleniumPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.src.qa.utilities.TakeScreenShot;


public class ScreenShotTest {
 WebDriver driver;

 @BeforeMethod
 public void setup() {
  System.setProperty("webdriver.chrome.driver",
    "F:\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
  driver = new ChromeDriver();
  driver.manage().window().maximize();
  driver.get("https://www.google.com/");
 }
 @Test
 public void testCase1() {
  driver.findElement(By.name("q")).sendKeys("ScreenShot Demo");
  Assert.assertTrue(false);
 }
 @Test
 public void testCase2() {
  Assert.assertTrue(true);
 }
 @AfterMethod
 public void tearDown(ITestResult result) {
  if(result.FAILURE==result.getStatus())
  {
   TakeScreenShot.screenShot(driver, result.getName());
  }
  driver.close();
 }
}