package javaSeleniumPractice;


import org.testng.annotations.Test;

public class testChield extends testsuper{

//	testChield(){
//		
//		super();
//	}
//	
	public static void main(String[] args) {
		
		
		ImSuper();
		
	}
	
	
	
	
}
