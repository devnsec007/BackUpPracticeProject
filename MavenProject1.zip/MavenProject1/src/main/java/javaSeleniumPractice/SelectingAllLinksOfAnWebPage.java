package javaSeleniumPractice;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SelectingAllLinksOfAnWebPage {

	WebDriver driver;
	
	
	@BeforeMethod
	public void Setup() {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"\\Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
	}
	
	
	
	@Test
	public void SelectingAllLinks() {
		
		driver.get("https://www.google.com/");
		List<WebElement>  ListOfElements = driver.findElements(By.tagName("a"));
		
		System.out.println("List of Anchor Tags on Google Page::" + "\n");
		
		
		for(WebElement Ele:ListOfElements) {
			
			if(Ele.isEnabled())
			System.out.println(Ele.getText());
			
		}
		
		driver.quit();
	}
	
	
	
}
