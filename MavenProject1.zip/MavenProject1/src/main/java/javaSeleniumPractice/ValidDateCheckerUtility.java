package javaSeleniumPractice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class ValidDateCheckerUtility {

	public static void main(String[] args) {

		System.out.println("Enter the Date in dd-mm-yyyy format ::");
		
		Scanner SC =new Scanner(System.in);
		
		String INDATE = SC.nextLine();
		Boolean ISDATE = ValidDateCheck(INDATE);
		
		if (ISDATE)
		System.out.println("Yes This is a valid date");
		else
		System.out.println("No This is not a valid date");
		
		
				
	}

	public static Boolean ValidDateCheck(String INDATE) {
		
		SimpleDateFormat SIMDF = new SimpleDateFormat("dd-MM-yyyy");
		SIMDF.setLenient(false);	
		//Date DD = null;
		
		
		try {
		 SIMDF.parse(INDATE.trim());
		 return true;
		}
		
		catch(Exception e) {
			
			return false;
			
			
		}
		
	}
	
	
}
