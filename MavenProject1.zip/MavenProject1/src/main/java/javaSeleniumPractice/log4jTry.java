package javaSeleniumPractice;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.annotations.Test;

public class log4jTry {

	@Test
	public void Log4jTryDemo() {
		
		Logger loggerVar = LogManager.getLogger(log4jTry.class);
	
		
		loggerVar.info("--Info Log--");
		loggerVar.error("--Error Log--");
		loggerVar.debug("--Debug Log--");
		loggerVar.fatal("--Fatal Log--");
		
		
		
		
	}
	
	
}
