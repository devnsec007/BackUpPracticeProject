package javaSeleniumPractice;

import org.testng.Assert;
import org.testng.annotations.Test;

public class runFailedTestCases {

	@Test(retryAnalyzer = javaSeleniumPractice.testNGReRunfailedCases.class)
	public void Test001(){
		
		System.out.println("Failed");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Assert.assertTrue(false);
		
		
	}
	

	@Test
	public void Test002(){
		
		System.out.println("Pass");
		Assert.assertTrue(true);
		
		
	}
	
	
}
