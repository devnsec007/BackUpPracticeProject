package javaSeleniumPractice;

public interface myFirstInterface {

	int EmployeeID=0,salary=0;
	
	public void SetSalary(int EmployeeID);
	public int getSalary();
		
}
