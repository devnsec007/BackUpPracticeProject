package javaSeleniumPractice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;


import org.testng.annotations.Test;

public class MapPractice001 {

	
	
	@Test
	
	public void ArraylistTest() {
		
		ArrayList<String> ArrL1= new ArrayList<String>(); 
		
		ArrL1.add("Debasish");
		ArrL1.add("Koyel");
		ArrL1.add("KP");
		ArrL1.add("Rana");
		ArrL1.add("Rajesh");
		
		System.out.println("*******Hay This is the Array List Test*******");
		
		
		Iterator IT_Arraylist = ArrL1.iterator();
		
		while(IT_Arraylist.hasNext()){
		
			System.out.println(IT_Arraylist.next().toString());
			
		}


	}

@Test(priority = 1)
	
	public void hashMapTest() {
	
	
	Map<Integer,String> HMAP = new HashMap<Integer,String>();
	
	HMAP.put(10, "Debasish");
	HMAP.put(1, "Koyel");
	HMAP.put(3, "Koyel");
	HMAP.put(5, "Koyel");
	
	System.out.println("******Hay This is the HashMap List Test Traversing throygh Entry******");
	
	for(Entry<Integer, String> ETRY:HMAP.entrySet()) {
			
		System.out.println("This is the Key-->" + ETRY.getKey()+"<---->"+"This is the Value-->"+ETRY.getValue());
			
	}
	
	System.out.println("******Hay This is the HashMap List Test Traversing throygh Iterator*****");
	
	Iterator IT_Map = HMAP.entrySet().iterator();
	
	while(IT_Map.hasNext()) {
		
		Map.Entry MapElement =(Map.Entry) IT_Map.next();
		System.out.println("This is the Key-->" + MapElement.getKey()+"<---->"+"This is the Value-->"+MapElement.getValue());
		
	}
	
}
	

@Test(priority = 2)

public void Test002() {
	
	Map<Integer , Map<Integer,String> > HMAP = new HashMap<Integer, Map<Integer,String>>();
	
	
	Map<Integer,String> CMAP = new HashMap<Integer, String>();
	
	
	System.out.println("This is the example of map within a map*******************************************************");
	
	CMAP.put(10, "TEST01");
	CMAP.put(20, "TEST02");
	
	HMAP.put(1, CMAP);
	
	System.out.println(HMAP.get(1));
	
	
	
}
	
	
}
