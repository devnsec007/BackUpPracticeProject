package javaSeleniumPractice;

public class finallyKeyword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.out.println(function1());
		
	}

	
	
	private static int function1() {
		
		try{
			System.out.println("TRY");
			return 11;
			
		}
		finally {
			System.out.println("FINALLY");
			return 222;
		}
		
	}
}
