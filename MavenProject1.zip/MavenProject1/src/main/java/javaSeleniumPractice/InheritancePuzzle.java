package javaSeleniumPractice;

public class InheritancePuzzle {

	public static void main(String[] args) {
		System.out.println("I am within InheritancePuzzle Main");
}
	
	public  InheritancePuzzle(){
		System.out.println("Im within InheritancePuzzle Constructor");
	}
}

class secondclass extends InheritancePuzzle{
	public static void main(String[] args) {
		System.out.println("I am within Second Main");
		thirdClass TK=new thirdClass();

	}
public secondclass() {
		System.out.println("Im within secondclass Constructor");
	}
}
	
	class thirdClass extends secondclass{
		public  thirdClass() {
			System.out.println("Im within thirdClass Constructor");
		}
	
public static void main(String[] args) {
	
			System.out.println("I am within thirdClass Main");
			thirdClass TD=new thirdClass();
			
			
		}
	
}
