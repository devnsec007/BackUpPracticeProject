package javaSeleniumPractice;

public class customizableExceptions {

	public static void main(String[] args) {
	
		int k= customizableExceptions.customExcep1();

	}

	
	public static int customExcep1() {
		
		int i=0,k;
		
		char[] JavaCharArray = new char[2];
		
		
		try {
		
		  
		  
			JavaCharArray[2] = 'c';  
		
			
			throw new ArrayIndexOutOfBoundsException ("Ole baba chotto Array");
				
		}
		
		catch(ArithmeticException e) {
						
			System.out.println("Aaa Dhorechi");
			
			
		}
		
		catch(ArrayIndexOutOfBoundsException e) {
			
			System.out.println(" Dhorechi");
			
			
		}
		
		
		return i;
	}
	
	
	
	
}
