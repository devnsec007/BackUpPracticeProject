package javaSeleniumPractice;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class robotClassExample {
	
	WebDriver driver;
	
	@BeforeTest
	public void Setup() {
		
		System.setProperty("webdriver.chrome.driver",
			    "F:\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
			  driver = new ChromeDriver();
			  driver.manage().window().maximize();
			  driver.get("https://www.google.com/");
		
	}
	
	
	@Test(priority = 1)
	public void Test001() throws Exception {
		
		RobotMethod() ;
		driver.quit();
	}
	
	
	
	public void RobotMethod() throws AWTException, Exception {
		
		Robot ROBJ = new Robot();
		  ROBJ.mouseMove(500, 300);
		  ROBJ.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		  ROBJ.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_A);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_P);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_P);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_L);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_E);
		  Thread.sleep(1000);
		  ROBJ.keyPress(KeyEvent.VK_ENTER);
		  Thread.sleep(2000);
		  
	}
	
		
	@Test(priority = 2)
	public void TEST002() throws Exception, Exception {
		Runtime.getRuntime().exec("notepad");
		
		  Thread.sleep(2000);
		RobotMethod() ;
		
		
	}
	
	
	
	
}
