package javaSeleniumPractice;

import java.util.Scanner;

public class VariableConversion {

	
	public static void main(String[] args) {
		Object O,K;
		String S=null;
		int i =0;
		Scanner myObj1 = new Scanner(System.in); 
		
		O = GettheString(myObj1);
		StringToNumber(O);
		
		Scanner myObj2 = new Scanner(System.in);
		K=GettheString(myObj2);
		IntegerToString(K);
		
		
	}
	
	
	public static void StringToNumber(Object O) {
		
		String S = (String) O;
				
		try {
		// int I = Integer.parseInt(S);
			int I = Integer.valueOf(S);
		
		System.out.println("The Integer corresponding value of the variable is :" + I);
		}
		
		catch(Exception e) {
			
			System.out.println("The String value entered cant be changed to Integer");
		}
		
		
		
	}
	
	public static Object GettheString(Scanner myObj) {
		
		System.out.println("Enter the String ::");
		
		String S = myObj.nextLine();
		
		return S;
	}
	
	public static void IntegerToString(Object O) {
		
		
		String S;
		try {
			int i =  Integer.valueOf((String) O);
			S = String.valueOf(i);
			
			System.out.println("The String corresponding value of the variable is : " + S);
		}
		
		catch(Exception e) {
			
			System.out.println("Entered Integer cant be converted to String");
		}
		
		
	}

}
