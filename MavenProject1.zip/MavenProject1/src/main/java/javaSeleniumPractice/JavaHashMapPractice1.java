package javaSeleniumPractice;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class JavaHashMapPractice1 {

	public static void main(String[] args) {

		Scanner Scn = new Scanner(System.in);
		HashMap<Integer,String> MP = new HashMap<Integer,String>(); //declaring hashMap Varidable
		
		System.out.println("Enter Number Of Entries you want to create in Map: ");
		int i= Scn.nextInt();
		
		//Entering Value on the HashMap
		
		for(int k =1;k<=i;k++) {
		
			System.out.println("Enter Entry: ");
			

			String S=Scn.next();
			MP.put(k, S);
			
		}
		
		MP.put(1, "Changed By Put"); //Modifying Value on the hashMap
		
		
		
		
		
		System.out.println("Entered HashMap is (Through Map.Entry) :");
		
		
		//Printing Values of the Hasmap through Entry
		
		
		
		for(Map.Entry M: MP.entrySet()) {
			
			System.out.println("Key:: " + M.getKey()+"  Value:: " + M.getValue());
			
		}
		
		System.out.println("Entered HashMap is (Through Iterator as Object Iterator) :");
		
		Set SS = MP.entrySet();
		
		Iterator Ita = SS.iterator();
		
		while(Ita.hasNext()) {
			
			Map.Entry MM=(Map.Entry)Ita.next();
			System.out.println("Key:: " + MM.getKey()+"  Value:: " + MM.getValue());
			
			
		}
		
		
		System.out.println("Entered HashMap is (Through Iterator as Integer Iterator) :");
		
		Iterator ITR2 = MP.keySet().iterator();
		
		while(ITR2.hasNext()) {
			
			int Key=(Integer)ITR2.next();
			
			System.out.println("Key:: " + Key+"  Value:: " + MP.get(Key).toString());
			
			
		}
		
		
		
		
		
	}

	
	
	
	
}
