package javaSeleniumPractice;

import org.testng.annotations.Test;

public class InterfaceTesting implements myFirstInterface {

	
	int newEmployeeID  ;
	
	
	@Test
	public void TestingInterface() {
		
		SetSalary(200056);
		System.out.println("My Salary is " +getSalary() );
		
	}
	
	
	
	@Override
	public void SetSalary(int EmployeeID) {
		
		newEmployeeID = EmployeeID;
		
	}

	@Override
	public int getSalary() {
	
		if(newEmployeeID==200056)
		return 10000000;
		
		else
		return 0;
	}

}
