package javaSeleniumPractice;

public class SwapwithoutThirdVariable {

	public static void main(String[] args) {

		String A="Debasish";
		String B="Biswas";
		
		System.out.println("Before the Swap :: Value of String A = " + A + "  Value of String B = " +B );
		
		A=A+B; //DebasishBiswas
		B= A.substring(0,A.indexOf(B));
		A=A.substring(B.length());
		
		System.out.println("After the Swap :: Value of String A = " + A + "  Value of String B = " +B );
		
		
		
		

	}

}
