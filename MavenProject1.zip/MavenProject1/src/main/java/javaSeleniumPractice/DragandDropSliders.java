package javaSeleniumPractice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DragandDropSliders {
	WebDriver driver;
	
@BeforeMethod

public void Setup() throws Exception {
	
	//Driver Initialization and Default site reach
			System.setProperty("webdriver.chrome.driver","C:\\Users\\DB\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
			driver= new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			driver.get("https://www.seleniumeasy.com/test/");
			
			
			//Handling the Add thats appearing
			if(driver.findElement(By.xpath("//div[@class='at4win-header']/a")).isEnabled())
				driver.findElement(By.xpath("//div[@class='at4win-header']/a")).click();
			
			Thread.sleep(2000);
			
			
			//NavigateToDesiredWebPage
			Navigation(driver);
}
	
public void Navigation(WebDriver driver) {
	
	driver.findElement(By.xpath("//li[@class='dropdown']/a[contains(text(),'Progress Bars')]")).click();
	driver.findElement(By.xpath("//li[@class='dropdown open']//a[contains(text(),'Drag & Drop Sliders')]")).click();
	
}
	
	@Test
	
	public void SlideTheSliderToMatchAValue() throws Exception {
		
		
		
		String BEFORE = driver.findElement(By.xpath("//div[@id='slider1']/div/output")).getText();
		
		Thread.sleep(2000);
		
		Actions AC = new Actions(driver);
		AC.dragAndDropBy(driver.findElement(By.xpath("//div[@id='slider1']/div/input")), 60,0).build().perform();
		
		Thread.sleep(2000);
		
		String AFTER = driver.findElement(By.xpath("//div[@id='slider1']/div/output")).getText();
		
		
		Assert.assertTrue(!AFTER.equalsIgnoreCase(BEFORE));
		
		
	}
	
	@AfterMethod
	
	public void TearDown() throws Exception {
		
		Thread.sleep(3000);
		driver.quit();
		
	}
	
}
