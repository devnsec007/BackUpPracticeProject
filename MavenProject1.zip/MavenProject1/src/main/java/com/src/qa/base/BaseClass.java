package com.src.qa.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {

	static Properties prop;
	public static WebDriver driver;
	
	public BaseClass() throws IOException {
		 
		prop = new Properties() ;
		FileInputStream SRC = new  FileInputStream("F:\\eclipse-workspace\\MavenProject1\\src\\main\\java\\com\\src\\qa\\config\\configuration.properties");
		
		prop.load(SRC);
		
	}
	
	public static void initialization() {
		
		if (prop.getProperty("browser").equalsIgnoreCase("chrome") ) {
			
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\DB\\eclipse-workspace\\MavenProject1\\Driver\\chromedriver.exe");
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
			
		}
		

		else {
			
			System.out.println("No Such Browser support available at the moment");
			System.exit(0);
		}
		
		driver.get(prop.getProperty("baseurl"));
		
		
	}
	
}
